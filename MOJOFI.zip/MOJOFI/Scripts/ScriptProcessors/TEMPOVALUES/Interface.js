Content.makeFrontInterface(200, 100);

reg init = 0;

const var Label1 = Content.getComponent("Label1");

const var Knob1 = Content.getComponent("Knob1");
Knob1.setControlCallback(Knob1CB);

const var tempoValues = ["1/1", "1/2D", "1/2", "1/2T", "1/4D", "1/4", "1/4T", "1/8D", "1/8", "1/8T", "1/16D", "1/16", "1/16T", "1/32D", "1/32", "1/32T", "1/64D", "1/64", "1/64T"


];

inline function Knob1CB(control, value)
{
   
    
   
   //     Label1.set("text", value);
        
        Label1.set("text", tempoValues[value]);

    Label1.changed();
  
}



function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{
	
}
 