Content.makeFrontInterface(1000, 667); 

//controls delay
const var syncms = Content.getComponent("syncms");

const var leftdelay = Content.getComponent("leftdelay");

const var leftdelayms = Content.getComponent("leftdelayms");


const var rightdelayms = Content.getComponent("rightdelayms");

const var rightdelay = Content.getComponent("rightdelay");






const var Delay1 = Synth.getEffect("Delay1");



//valdymas delay



inline function onsyncmsControl(number, value)
{
	
Delay1.setAttribute(Delay1.TempoSync, value);
        leftdelay.showControl(value);
        leftdelayms.showControl(1-value);
        
        rightdelay.showControl(value);
                rightdelayms.showControl(1-value);
            
}

syncms.setControlCallback(onsyncmsControl);







function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{

if (number == syncms)
   {
       leftdelay.showControl(value);
       leftdelayms.showControl(1-value);
   }
	
}
 