Content.makeFrontInterface(1000, 667); 

//controls delay
const var syncms = Content.getComponent("syncms");

const var leftdelay = Content.getComponent("leftdelay");

const var leftdelayms = Content.getComponent("leftdelayms");


const var rightdelayms = Content.getComponent("rightdelayms");

const var rightdelay = Content.getComponent("rightdelay");






const var Delay1 = Synth.getEffect("Delay1");



//valdymas delay



inline function onsyncmsControl(number, value)
{
	
Delay1.setAttribute(Delay1.TempoSync, value);
        leftdelay.showControl(value);
        leftdelayms.showControl(1-value);
        
        rightdelay.showControl(value);
                rightdelayms.showControl(1-value);
            
}

syncms.setControlCallback(onsyncmsControl);

//////////////// BEGINING OF THE PRESET BROSER WINDOW //////////////////////////


const var PRESET_Bar = Content.addPanel("PRESET_Bar", 0, 86);

Content.setPropertiesFromJSON("PRESET_Bar", {
    "width": 1000,
    "height": 50,
  //  "itemColour": 2149325852,
    "itemColour": 0x00839DA9,
    "itemColour2": 0x00839DA9,
    "textColour": "268435455",
    "borderSize": 0,
    "visible": true,
    "borderRadius": 0,
});






const var PRESET_Opener = Content.addButton("PRESET_Opener", 1, 1);

Content.setPropertiesFromJSON("PRESET_Opener", {
    "height": 50,
    "width": 1000,
  //  "text": "PRESET BROWSER",
    "text": "PRESET BRO",
    "parentComponent": "PRESET_Bar",
    "isMomentary": true,
    "bgColour": 0x00839DA9,
    "itemColour": 0x00839DA9,
    "itemColour2": 0x00839DA9
});

inline function onPRESET_OpenerControl(component, value)
{
    if (value == 1)
        {
        PRESET_Container.set("visible", true);
        }
};

Content.getComponent("PRESET_Opener").setControlCallback(onPRESET_OpenerControl);







const var PRESET_Container = Content.addPanel("PRESET_Container", 160, 135);

Content.setPropertiesFromJSON("PRESET_Container", {
    "width": 573,
    "height": 435,
    "itemColour": 4194764551,
    "itemColour2": 4077324039,
    "textColour": "268435455",
    "borderSize": 1,
    "visible": false,
    "borderRadius": 0,
});





const var PRESET_Closer = Content.addButton("PRESET_Closer", 473, 1);

Content.setPropertiesFromJSON("PRESET_Closer", {
    "height": 28,
    "width": 86,
    "isMomentary": true,
    "text": "CLOSE",
    "parentComponent": "PRESET_Container",
    "bgColour": 16777215,
    "itemColour": 371335714,
    "itemColour2": 4077981969
});

inline function onPRESET_CloserControl(component, value)
{
    if (value == 1)
        {
        PRESET_Container.set("visible", false);
        }
};

Content.getComponent("PRESET_Closer").setControlCallback(onPRESET_CloserControl);







const var PRESET_Browser = Content.addFloatingTile("PRESET_Browser", 160, 5);

//Content.setPropertiesFromJSON("PRESET_Browser", {
//   "bgColour": 4160749568,
//    "itemColour": 4290953929,
//    "itemColour2": 3092597581,
//    "textColour": 3267409337,
//    "ContentType": "PresetBrowser",
//    "Data": "{\r\n}",
//    "Font": "Arial",
//    "width": 554,
 //   "height": 328,
//    "parentComponent": "PRESET_Container"
//});







namespace UserPresetWidgets
{
	/** Creates a arrow button that cycles through the current category. */
	inline function createPresetButton(name, x, y, up)
	{
		local widget = Content.addPanel(name, x, y);
    
		Content.setPropertiesFromJSON(name, {
		"width": 15,
		"height": 20,
		"saveInPreset": false,
		"tooltip": up ? "Load next user preset" : "Load previous user preset",
        "parentComponent": "PRESET_Bar",
		"allowCallbacks": "Clicks & Hover"
		});
    
		widget.data.up = up;
    
		widget.setPaintRoutine(function(g)
		{
			g.setColour(this.data.hover ? 0x20FFFFFF : 0x28FFFFFF);
			g.fillTriangle([0, 0, this.getWidth(), this.getHeight()], this.data.up ? Math.PI/2 : 1.5 * Math.PI);
		});
    
		widget.setMouseCallback(function(event)
		{
			this.data.hover = event.hover;
    	
			if(event.clicked)
			{
				if(this.data.up)
					Engine.loadNextUserPreset(true);
				else
					Engine.loadPreviousUserPreset(true);		
			}
    	
			this.repaint();
		});
		return widget;
	};

	/** Creates a Label that shows the current User Preset.
	*
	*	You can click on it and it will open up a popup with the preset browser.
	*
	*	Customization: Use the itemColour property of the Panel to set the
	*	Preset Browser Colour.
	*/
	inline function createPresetDisplay(name, x, y)
	{
		local widget = Content.addPanel(name, 270, y);
    
		Content.setPropertiesFromJSON(name, {
		"width": 512,
		"height": 59,
		"tooltip": "Click to show the Preset browser",
        "parentComponent": "PRESET_Bar",
		});
    
    
		widget.setPaintRoutine(function(g)
		{
			g.fillAll(this.data.hover ? 0x00252526 : 0x00252526);
			g.setColour(0x01FFFFFF);
			g.drawRect([0, 0, this.getWidth(), this.getHeight()], 1);
			g.setFont("Axiforma", 66.0);
			g.setColour(0xFF839DA9);
		//	g.setColour(0xFFadaea8);
			
    	
			g.drawAlignedText(Engine.getCurrentUserPresetName(), [10, 0, this.getWidth(), this.getHeight()], "left");
		});
    
		widget.setTimerCallback(function()
		{
			this.repaint();
		});
    
		widget.startTimer(300);
	
    
		widget.setMouseCallback(function(event)
		{
			this.data.hover = event.hover;
			this.repaint();
		});
		return widget;
	};

}


Engine.loadNextUserPreset(true);
const var UpButton = UserPresetWidgets.createPresetButton("UpButton", 487, 5, true);
const var DownButton = UserPresetWidgets.createPresetButton("DownButton", 451, 5, false);
const var PresetDisplay = UserPresetWidgets.createPresetDisplay("PresetDisplay", 129, 0);


/////////////////////// END OF THE PRESET BROSER WINDOW //////////////////////////





function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{

if (number == syncms)
   {
       leftdelay.showControl(value);
       leftdelayms.showControl(1-value);
   }
	
}
 