Content.makeFrontInterface(600, 500);
const var laf = Engine.createGlobalScriptLookAndFeel();
// A little helper function nicked from JUCE...
inline function removeFromTop(area, amountToRemove)
{
    local a = [area[0], area[1], area[2], amountToRemove];
    
    area[1] += amountToRemove;
    area[2] -= amountToRemove;
    return a;
}

laf.registerFunction("drawPresetBrowserDialog", function(g, obj)
{
   g.fillAll(0x88000000) ;
   g.setColour(0xFF555555);
   g.fillRoundedRectangle(obj.area, 5.0);
   g.setColour(0xFF333333);
   g.fillRoundedRectangle(obj.labelArea, 5.0);
   g.setColour(0xFF540000);
    g.drawAlignedText(obj.title, removeFromTop(obj.area, 20), "centred");
  // g.drawAlignedText(obj.text, removeFromTop(obj.area, 30), "centred");
    
});function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{
	
}
 