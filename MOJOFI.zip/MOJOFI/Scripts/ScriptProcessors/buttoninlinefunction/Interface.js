Content.makeFrontInterface(600, 500);

const var button = Content.getComponent("Button1");
const var knob1 = Content.getComponent("Knob1");
const var knob2 = Content.getComponent("Knob2");

inline function onButton1Control(number, value)
{
        knob1.showControl(value);
        knob2.showControl(1-value);    
}

button.setControlCallback(onButton1Control);




function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{
	
}
 