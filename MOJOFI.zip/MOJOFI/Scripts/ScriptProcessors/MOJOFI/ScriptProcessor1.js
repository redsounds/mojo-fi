Content.makeFrontInterface(1000, 667); 

//controls delay
const var syncms = Content.getComponent("syncms");

const var leftdelay = Content.getComponent("leftdelay");

const var leftdelayms = Content.getComponent("leftdelayms");


const var rightdelayms = Content.getComponent("rightdelayms");

const var rightdelay = Content.getComponent("rightdelay");



//labels
const var RightLabel = Content.getComponent("RightLabel");

const var tempoValuesR = ["1/1", "1/2D", "1/2", "1/2T", "1/4D", "1/4", "1/4T", "1/8D", "1/8", "1/8T", "1/16D", "1/16", "1/16T", "1/32D", "1/32", "1/32T", "1/64D", "1/64", "1/64T"


];

const var LeftLabel = Content.getComponent("LeftLabel");

const var tempoValuesL = ["1/1", "1/2D", "1/2", "1/2T", "1/4D", "1/4", "1/4T", "1/8D", "1/8", "1/8T", "1/16D", "1/16", "1/16T", "1/32D", "1/32", "1/32T", "1/64D", "1/64", "1/64T"


];


//label ms
const var RightLabelms = Content.getComponent("RightLabelms");

const var LeftLabelms = Content.getComponent("LeftLabelms");

const var Delay1 = Synth.getEffect("Delay1");
const var Delay2 = Synth.getEffect("Delay2");
const var Dry = Synth.getEffect("Dry");
const var Wet = Synth.getEffect("Wet");


const var Leftfeedback = Content.getComponent("Leftfeedback");

const var Rightfeedback = Content.getComponent("Rightfeedback");





//labels valdymas


inline function onrightdelayControl(component, value)
{
Delay1.setAttribute(Delay1.DelayTimeRight, value);
        
        RightLabel.set("text", tempoValuesR[value]);

    RightLabel.changed();

};

Content.getComponent("rightdelay").setControlCallback(onrightdelayControl);

/////

inline function onleftdelayControl(component, value)
{
Delay1.setAttribute(Delay1.DelayTimeLeft, value);
        
        LeftLabel.set("text", tempoValuesL[value]);

    LeftLabel.changed();
};

Content.getComponent("leftdelay").setControlCallback(onleftdelayControl);

////labels ms


inline function onleftdelaymsControl(component, value)
{
	Delay2.setAttribute(Delay2.DelayTimeLeft, value);
        
        LeftLabelms.set("text", Math.round(value)+ " ms");

    LeftLabelms.changed();
};

Content.getComponent("leftdelayms").setControlCallback(onleftdelaymsControl);



inline function onrightdelaymsControl(component, value)
{
	Delay2.setAttribute(Delay2.DelayTimeRight, value);
        
        RightLabelms.set("text", Math.round(value)+ " ms");

    RightLabelms.changed();
};

Content.getComponent("rightdelayms").setControlCallback(onrightdelaymsControl);




//Math.round(value*100) + control.get("suffix")







//valdymas delay



inline function onsyncmsControl(number, value)
{
	
	Delay1.setBypassed(1-value);
	Delay2.setBypassed(value);
//Delay1.setAttribute(Delay1.TempoSync, value);
        leftdelay.showControl(value);
        leftdelayms.showControl(1-value);
        
        RightLabel.showControl(value);
        RightLabelms.showControl(1-value);
        
        rightdelay.showControl(value);
                rightdelayms.showControl(1-value);
    
    LeftLabel.showControl(value);
           LeftLabelms.showControl(1-value);
                
            
}

syncms.setControlCallback(onsyncmsControl);

//valdymas wet dry



inline function onGainWetDryControl(component, value)
{
		local wValue = Engine.getDecibelsForGainFactor(value);
	Wet.setAttribute(Wet.Gain, wValue);
	
	local dValue = Engine.getDecibelsForGainFactor(1.0 - value);
	Dry.setAttribute(Wet.Gain, dValue);
};

Content.getComponent("GainWetDry").setControlCallback(onGainWetDryControl);


////////// feedback valdymas


inline function onLeftfeedbackControl(component, value)
{
	Delay1.setAttribute(Delay1.FeedbackLeft, value);
	Delay2.setAttribute(Delay2.FeedbackLeft, value);
};

Content.getComponent("Leftfeedback").setControlCallback(onLeftfeedbackControl);


inline function onRightfeedbackControl(component, value)
{
	Delay1.setAttribute(Delay1.FeedbackRight, value);
	Delay2.setAttribute(Delay2.FeedbackRight, value);
};

Content.getComponent("Rightfeedback").setControlCallback(onRightfeedbackControl);






//////////////// BEGINING OF THE PRESET BROSER WINDOW //////////////////////////


const var PRESET_Bar = Content.addPanel("PRESET_Bar", 0, 86);

Content.setPropertiesFromJSON("PRESET_Bar", {
    "width": 1000,
    "height": 50,
  //  "itemColour": 2149325852,
    "itemColour": 0x00839DA9,
    "itemColour2": 0x00839DA9,
    "textColour": "268435455",
    "borderSize": 0,
    "visible": true,
    "borderRadius": 0,
});






const var PRESET_Opener = Content.addButton("PRESET_Opener", 1, 1);

Content.setPropertiesFromJSON("PRESET_Opener", {
    "height": 50,
    "width": 1000,
  //  "text": "PRESET BROWSER",
    "text": "PRESET BRO",
    "parentComponent": "PRESET_Bar",
    "isMomentary": true,
    "bgColour": 0x00839DA9,
    "itemColour": 0x00839DA9,
    "itemColour2": 0x00839DA9
});

inline function onPRESET_OpenerControl(component, value)
{
    if (value == 1)
        {
        PRESET_Container.set("visible", true);
        }
};

Content.getComponent("PRESET_Opener").setControlCallback(onPRESET_OpenerControl);







const var PRESET_Container = Content.addPanel("PRESET_Container", 0, 135);

Content.setPropertiesFromJSON("PRESET_Container", {
    "width": 1000,
    "height": 400,
    "itemColour": 0xFF2b3d43,
    "itemColour2": 0xFF2b3d43,
    "textColour": "268435455",
    "borderSize": 1,
    "visible": false,
    "borderRadius": 0,
});





const var PRESET_Closer = Content.addButton("PRESET_Closer", 960, 15);

Content.setPropertiesFromJSON("PRESET_Closer", {
    "height": 28,
    "width": 86,
    "isMomentary": true,
    "text": "CLOSE",
    "parentComponent": "PRESET_Container",
    "bgColour": 16777215,
    "itemColour": 371335714,
    "itemColour2": 4077981969
});

inline function onPRESET_CloserControl(component, value)
{
    if (value == 1)
        {
        PRESET_Container.set("visible", false);
        }
};

Content.getComponent("PRESET_Closer").setControlCallback(onPRESET_CloserControl);







const var PRESET_Browser = Content.addFloatingTile("PRESET_Browser", 105, 5);

//Content.setPropertiesFromJSON("PRESET_Browser", {
//   "bgColour": 4160749568,
//    "itemColour": 4290953929,
//    "itemColour2": 3092597581,
//    "textColour": 3267409337,
//    "ContentType": "PresetBrowser",
//    "Data": "{\r\n}",
//    "Font": "Arial",
//    "width": 554,
 //   "height": 328,
//    "parentComponent": "PRESET_Container"
//});







namespace UserPresetWidgets
{
	/** Creates a arrow button that cycles through the current category. */
	inline function createPresetButton(name, x, y, up)
	{
		local widget = Content.addPanel(name, x, y);
    
		Content.setPropertiesFromJSON(name, {
		"width": 50,
		"height": 25,
		"saveInPreset": false,
		"tooltip": up ? "Load next user preset" : "Load previous user preset",
        "parentComponent": "PRESET_Bar",
		"allowCallbacks": "Clicks & Hover"
		});
    
		widget.data.up = up;
    
		widget.setPaintRoutine(function(g)
		{
			g.setColour(this.data.hover ? 0x00FFFFFF : 0x00FFFFFF);
//			g.fillTriangle([0, 0, this.getWidth(), //this.getHeight()], this.data.up ? Math.PI/2 : 1.5 * Math.PI);
			g.fillRect([0, 0, this.getWidth(), this.getHeight()]);		
			
		});
    
		widget.setMouseCallback(function(event)
		{
			this.data.hover = event.hover;
    	
			if(event.clicked)
			{
				if(this.data.up)
					Engine.loadNextUserPreset(true);
				else
					Engine.loadPreviousUserPreset(true);		
			}
    	
			this.repaint();
		});
		return widget;
	};

	/** Creates a Label that shows the current User Preset.
	*
	*	You can click on it and it will open up a popup with the preset browser.
	*
	*	Customization: Use the itemColour property of the Panel to set the
	*	Preset Browser Colour.
	*/
	inline function createPresetDisplay(name, x, y)
	{
		local widget = Content.addPanel(name, 235, y);
 //presetso vieta   
		Content.setPropertiesFromJSON(name, {
		"width": 512,
		"height": 53,
		"tooltip": "Click to show the Preset browser",
        "parentComponent": "PRESET_Bar",
		});
    
    
		widget.setPaintRoutine(function(g)
		{
			g.fillAll(this.data.hover ? 0x00252526 : 0x00252526);
			g.setColour(0x01FFFFFF);
			g.drawRect([0, 0, this.getWidth(), this.getHeight()], 1);
			g.setFont("Axiforma", 55.0);
			g.setColour(0xFF839DA9);
		//	g.setColour(0xFFadaea8);
			
    	
			g.drawAlignedText(Engine.getCurrentUserPresetName(), [10, 0, this.getWidth(), this.getHeight()], "centred");
		});
    
		widget.setTimerCallback(function()
		{
			this.repaint();
		});
    
		widget.startTimer(300);
	
    
		widget.setMouseCallback(function(event)
		{
			this.data.hover = event.hover;
			this.repaint();
		});
		return widget;
	};

}


Engine.loadNextUserPreset(true);
const var UpButton = UserPresetWidgets.createPresetButton("UpButton", 784, 11, true);
const var DownButton = UserPresetWidgets.createPresetButton("DownButton", 168, 11, false);
const var PresetDisplay = UserPresetWidgets.createPresetDisplay("PresetDisplay", 129, 0);


/////////////////////// END OF THE PRESET BROSER WINDOW //////////////////////////

//LOOK AND FEEL

const var laf = Engine.createGlobalScriptLookAndFeel();

laf.registerFunction("drawPresetBrowserSearchBar", function(g, obj)
{
   g.setColour(0x00FFFFFF); 
   
   
    
    
});

inline function removeFromTop(area, amountToRemove)
{
    local a = [area[0], area[1], area[2], amountToRemove];
    
    area[1] += amountToRemove;
    area[2] -= amountToRemove;
    return a;
}


laf.registerFunction("drawPresetBrowserDialog", function(g, obj)
{
 g.fillAll(0x00000000) ;
 g.setColour(0xFF34454B);
  // g.setColour(0x40789FAB);#FF34454B
   g.fillRoundedRectangle(obj.area, 5.0);
   //g.setColour(0xFF333333);
   g.setColour(0xFF2b3d43);
   g.fillRoundedRectangle(obj.labelArea, 5.0);
   g.setColour(0xFF789FAB);

g.drawAlignedText(obj.title, removeFromTop(obj.area, 45), "centred"); 
});

laf.registerFunction("drawDialogButton", function(g, obj)
{

g.fillAll(0x00000000);

    
        if(obj.over)
 
           g.fillAll(0x10000000);
   
     
        if(obj.down)
           
g.fillAll(0x10000000);


  
g.setColour(0xFF789FAB);
  
      g.drawAlignedText(obj.text, obj.area, "centred");


	
	});

//Label1.set("text", value);
function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{

if (number == syncms)
   {
       leftdelay.showControl(value);
       leftdelayms.showControl(1-value);
   }
	
}
 