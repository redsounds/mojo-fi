Content.makeFrontInterface(670, 385);

const var LeftDelayTimerSync = Content.getComponent("LeftDelayTimerSync");
const var RightDelayTimerSync = Content.getComponent("RightDelayTimerSync");
const var SyncFreeButton = Content.getComponent("SyncFreeButton");
const var Delay3 = Synth.getEffect("Delay3");

// [JSON Knob]

Content.setPropertiesFromJSON("LeftDelayTimerSync", {
  "mode": "TempoSync",
  "stepSize": 1,
});

Content.setPropertiesFromJSON("RightDelayTimerSync", {
  "mode": "TempoSync",
  "stepSize": 1,
});



inline function onSyncFreeButtonControl(component, value)
{
	 Delay3.setAttribute(Delay3.TempoSync, value);
	
	if(value)
	{
		// Switch the knob to tempo sync mode
		LeftDelayTimerSync.set("mode", "TempoSync");
		LeftDelayTimerSync.set("max", 10);
		LeftDelayTimerSync.set("min", 0);
		LeftDelayTimerSync.set("stepSize", 1);
		LeftDelayTimerSync.set("middlePosition", 9);
		
		RightDelayTimerSync.set("mode", "TempoSync");
		RightDelayTimerSync.set("max", 10);
		RightDelayTimerSync.set("min", 0);
		RightDelayTimerSync.set("stepSize", 1);
		RightDelayTimerSync.set("middlePosition", 9);		
	}
	else
	{
		// Switch the knob to frequency mode
		LeftDelayTimerSync.set("mode", "Time");
		LeftDelayTimerSync.set("min", 0.5);
		LeftDelayTimerSync.set("max", 1400);
		LeftDelayTimerSync.set("middlePosition", 700);
		LeftDelayTimerSync.set("stepSize", 0.01);
				
		RightDelayTimerSync.set("mode", "Time");
		RightDelayTimerSync.set("min", 0.5);
		RightDelayTimerSync.set("max", 1400);
		RightDelayTimerSync.set("middlePosition", 700);
		RightDelayTimerSync.set("stepSize", 0.01);
		
	}
	
    LeftDelayTimerSync.setValue(Delay3.getAttribute(Delay3.DelayTimeLeft));
    RightDelayTimerSync.setValue(Delay3.getAttribute(Delay3.DelayTimeRight));
};

SyncFreeButton.setControlCallback(onSyncFreeButtonControl);


function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{
    /*  This callback just calls the page handling function with the respective page.
    *   The other custom callbacks are implemented in the onInit script.
    */
	switch(number)
    {
        case FrontPanelButton: handlePages(FrontPanel); break;
        case CreditsPageButton: handlePages(CreditsPage); break;
           }
}