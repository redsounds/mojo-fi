Content.makeFrontInterface(600, 600);

const var Delay1 = Synth.getEffect("Delay1");

const var Button1 = Content.getComponent("Button1");




inline function onButton1Control(component, value)
{
Delay1.setAttribute(Delay1.TempoSync, value);
};

Content.getComponent("Button1").setControlCallback(onButton1Control);



function onNoteOn()
{
	
}
 function onNoteOff()
{
	
}
 function onController()
{
	
}
 function onTimer()
{
	
}
 function onControl(number, value)
{
	
}
 